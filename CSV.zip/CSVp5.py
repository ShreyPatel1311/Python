import csv
with open("student1.csv",'r',newline='\r\n') as f:
    csvreader=csv.reader(f)
    for data in csvreader:
        if data[1][0]=='A' or data[1][0]=='a':
            print(data)
        elif data[1][0]=='E' or data[1][0]=='e':
            print(data)
        elif data[1][0]=='I' or data[1][0]=='i':
            print(data)
        elif data[1][0]=='O' or data[1][0]=='O':
            print(data)
        elif data[1][0]=='U' or data[1][0]=='u':
            print(data)
