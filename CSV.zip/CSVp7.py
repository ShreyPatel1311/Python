import csv
with open("student1.csv",'r',newline='\r\n') as f:
    stureader=csv.reader(f)
    for data in stureader:
        if data[-1]=='B':
            print(data)
f.close()
