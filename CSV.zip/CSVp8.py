import csv
with open("student1.csv",'r',newline='\r\n') as f:
    stureader=csv.reader(f)
    for data in stureader:
        if len(data[1])>10:
            print(data)
f.close()
