import csv
with open("student1.csv",'r',newline='\r\n') as f:
    stureader=csv.reader(f)
    for data in stureader:
        if data[2]>'90':
            print(data)
f.close()
