import csv
import os.path
file_exists=os.path.isfile("student1.csv")
with open("student1.csv",'a',newline='') as f:
    Fl=['rollno','name','Marks','Class','Section']
    stuwriter=csv.writer(f)
    if not file_exists:
        stuwriter.writerow(Fl)
    ch='y'
    while True:
        try:
            rollno=int(input("enter rollno."))
            name=input("enter Name")
            Marks=int(input("enter Marks"))
            Class=int(input("enter Class"))
            Section=input("Enter Section")
            l=[rollno,name,Marks,Class,Section]
            sturec=stuwriter.writerow(l)
            ch=input("Would like to enter more data?[Y/N]:")
            if not ch=='Y' or ch=='y':
                print("you pressed wrong key")
                raise ValueError
            elif ch=='n' or ch=='N':
                f.close()
                exit()
        except ValueError:
            print("you entered wrong key")
            ch=input("Would you like to enter more data?[Y/N]:")
        except PermissionError:
            print("\nFile is corrupted.")
        except KeyboardInterrupt:
            f.close()
            exit()
