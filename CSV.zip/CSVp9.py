import csv
import os.path
FE=os.path.isfile("employee.csv")
with open("employee.csv",'a',newline='') as f:
    FL=['EMPId','EMPName','SALARY']
    empwriter=csv.writer(f)
    if not FE:
        empwriter.writerow(FL)
    n=int(input("How much employees of  data you want insert?"))
    for i in range(1,n+1):
        empId=int(input("enter EMPId"))
        empName=input("enter EMPName")
        salary=int(input("enter salary of Employee"))
        l=[empId,empName,salary]
        empwriter.writerow(l)
f.close()
