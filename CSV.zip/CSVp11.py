import csv
with open("employee.csv",'r',newline='\r\n') as f:
    csvreader=csv.reader(f)
    for data in csvreader:
        if data[1][0]=='A' or data[1][0]=='a':
            pass
        elif data[1][0]=='E' or data[1][0]=='e':
            pass
        elif data[1][0]=='I' or data[1][0]=='i':
            pass
        elif data[1][0]=='O' or data[1][0]=='O':
            pass
        elif data[1][0]=='U' or data[1][0]=='u':
            pass
        else:
            print(data)
            F=open("non-vowels.csv",'a',newline='\r\n')
            csvwriter=csv.writer(F)
            csvwriter.writerow(data)
f.close()
F.close()
