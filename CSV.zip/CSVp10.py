import csv
with open("employee.csv",'r',newline='\r\n') as f:
    empreader=csv.reader(f)
    for data in empreader:
        if data[-1]>'5000' or data[-1]<'10000':
            print(data)
f.close()
