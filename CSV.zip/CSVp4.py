import csv
with open("student1.csv",'r',newline='\r\n') as f:
    csvreader=csv.reader(f)
    for data in csvreader:
        if data[1][0]=='A' or data[1][0]=='a':
            print(data)
