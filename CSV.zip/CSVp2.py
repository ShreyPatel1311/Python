import csv
with open("student1.csv",'r',newline='\r\n') as f:
    creader=csv.reader(f)
    for data in creader:
        print(data)
    
